package nl.whitehorses.elegante.actor

import flex.messaging.MessageBroker
import flex.messaging.messages.AsyncMessage
import flex.messaging.util.UUIDUtils
import scala.actors._
import scala.actors.Actor._
import compat.Platform._
import net.liftweb.util._
import nl.whitehorses.elegante.model.Notification

/**
 * Deze class reageert op Notification berichten, vanuit
 * de Flex client.
 */
class Notifier extends Actor {

    //Get null pointer error, maybe configuratione error?
  val msgBroker = MessageBroker.getMessageBroker(null)
  val clientID = UUIDUtils.createUUID()
  val msg = new AsyncMessage()

  var notificationsSent = 0;

  def act{

    ActorPing.schedule(this, Notify, 500L)

    loop {
      react {

        /**
         * Bericht noticiation bericht ontvangen, regaeer na korte
         * tijd wachten.
         */
        case Notify =>
          msg.setDestination("notifications")
          msg.setClientId(clientID)
          msg.setMessageId(UUIDUtils.createUUID())
          msg.setTimestamp(currentTime)
          msg.setBody(new Notification(notificationsSent, "Hello from Scala/Lift", new java.util.Date()))
          msgBroker.routeMessageToService(msg, null)
          notificationsSent+=1
          println("notification sent at " + currentTime)
          ActorPing.schedule(this, Notify, 500L)
        
        case "stop" =>
          exit()
      }
    }
  }

}

case object Notify