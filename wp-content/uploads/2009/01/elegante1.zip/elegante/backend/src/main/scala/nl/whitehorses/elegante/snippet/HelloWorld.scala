package nl.whitehorses.elegante.snippet

class HelloWorld {
  def howdy = <span>Welcome to liftblaze at {new java.util.Date}</span>
}

