package nl.whitehorses.elegante.controller
/**
 * Created by IntelliJ IDEA.
 * User: gvdieijen
 * Date: 18-jan-2009
 * Time: 0:41:40
 * To change this template use File | Settings | File Templates.
 */

import net.liftweb.http._
import javax.servlet.http.{HttpServlet, HttpServletRequest , HttpServletResponse, HttpSession}
import nl.whitehorses.elegante.actor.Notifier

class WebServices (val request: RequestState) {

  def start_feed = {
    WebServices.notifier.start()
    XmlResponse(<start_feed success="true"/>)
  }

  def stop_feed = {
    WebServices.notifier ! "stop"
    XmlResponse(<stop_feed success="true"/>)
  }
}

object WebServices {
  val notifier = new Notifier()
}