package nl.whitehorses.elegante.model

/**
 * Deze class representeert een notificatie-bericht,
 * dat tussen de Flex-client en de Java backend wordt verstuurd.
 */
import java.util.Date

class Notification(var id: Int, var message: String, var timesent: Date)
{
    def getId = id
    def setId(id: Int) = this.id = id

    def getMessage = message
    def setMessage(m: String) = message = m

    def getTimesent = timesent
    def setTimesent(t: Date) = timesent = t
}